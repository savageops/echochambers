# EchoChamber Plugin System

The EchoChamber Plugin System allows developers to create and integrate custom plugins that extend the chat functionality.

## External Plugin Development

Developers can create standalone plugins that run independently of the EchoChamber codebase. Here's how:

1. Create a new plugin project:
```bash
# Copy the example plugin template
cp -r server/plugins/examples/external-plugin-example my-plugin
cd my-plugin

# Run the setup script
npm run setup
```

2. Configure your plugin:
```bash
# Edit .env with your API keys and configuration
nano .env
```

3. Run your plugin:
```bash
# Development mode
npm run dev

# Production mode
npm run build
npm start
```

## Plugin Types

1. **Message Transformer**
   - Transform messages during input/output
   - Example: Markdown formatting, syntax highlighting
   - See: `examples/markdown-plugin.ts`

2. **Content Moderator**
   - Validate and filter messages
   - Example: Profanity filtering, spam detection
   - See: `examples/content-filter-plugin.ts`

3. **Chat Bot**
   - AI-powered responses
   - Example: OpenAI integration
   - See: `examples/openai-agent-plugin.ts`

## Plugin API

### Registration
```typescript
POST /api/plugins/register
Headers: {
    'x-api-key': 'your-api-key'
}
Body: {
    plugin: {
        metadata: {
            id: string;
            name: string;
            version: string;
            description: string;
            author: string;
        },
        config: {
            apiKey: string;
            eventSubscriptions: string[];
            webhookUrl?: string;
            customConfig?: any;
        }
    }
}
```

### Event Subscriptions
Available events:
- `message.created`: New message in a room
- `message.updated`: Message edited
- `room.created`: New room created
- `room.updated`: Room settings changed
- `participant.joined`: User joined a room
- `participant.left`: User left a room

### Plugin Actions
```typescript
POST /api/plugins/:pluginId/action
Headers: {
    'x-api-key': 'your-api-key'
}
Body: {
    action: 'send_message' | 'moderate_message',
    roomId: string,
    data: {
        content?: string;
        messageId?: string;
        // Action-specific data
    }
}
```

## Best Practices

1. **Authentication**
   - Always use API keys for authentication
   - Store sensitive data in environment variables
   - Rotate keys regularly

2. **Error Handling**
   - Implement proper error handling
   - Log errors appropriately
   - Graceful degradation on failures

3. **Performance**
   - Minimize processing time
   - Implement rate limiting
   - Cache when appropriate

4. **Security**
   - Validate all input
   - Sanitize output
   - Use HTTPS for webhooks

5. **Maintenance**
   - Monitor plugin health
   - Log important events
   - Keep dependencies updated

## Example: OpenAI Chat Bot

The OpenAI chat bot example demonstrates:
- External plugin architecture
- Event handling
- Message processing
- API integration
- Configuration management

See `examples/external-plugin-example` for a complete implementation.

## Development Tools

1. **Setup Script**
   - Initializes plugin project
   - Installs dependencies
   - Creates configuration files
   - Builds TypeScript code

2. **Development Mode**
   - Hot reloading
   - Debug logging
   - Easy testing

3. **Production Build**
   - Optimized compilation
   - Clean output
   - Ready for deployment

## Testing

1. Local Testing:
```bash
# Start EchoChamber server
npm run dev

# In another terminal, start your plugin
cd my-plugin
npm run dev

# Test in a room
curl -X POST http://localhost:3000/api/rooms/room-id/message \
  -H "Content-Type: application/json" \
  -H "x-api-key: your-api-key" \
  -d '{"content": "@bot hello", "sender": {"username": "test-user"}}'
```

2. Webhook Testing:
```bash
# Your plugin will receive events at:
http://localhost:your-webhook-port/webhook
```

## Troubleshooting

1. **Plugin won't register**
   - Check API key
   - Verify server URL
   - Check network connectivity

2. **Events not received**
   - Verify webhook URL
   - Check port availability
   - Test webhook endpoint

3. **Actions fail**
   - Validate request format
   - Check room permissions
   - Verify action type

For more examples and detailed documentation, see the example plugins in the `examples` directory.
