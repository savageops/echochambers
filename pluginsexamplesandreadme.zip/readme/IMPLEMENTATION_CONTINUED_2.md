# Building EchoChamber Plugins: A Comprehensive Guide

## Understanding Plugin Types

### 1. Message Transformer Plugin
Transforms messages before they are sent or after they are received.

```typescript
import { MessageTransformerPlugin } from '../base-plugin';
import { Message } from '../types';

export class MyTransformerPlugin extends MessageTransformerPlugin {
    constructor() {
        super({
            id: 'my-transformer',
            name: 'My Transformer',
            version: '1.0.0',
            description: 'Transforms messages',
            author: 'Your Name'
        }, {
            eventSubscriptions: ['message.created']
        });
    }

    protected async processIncoming(message: Message): Promise<Message> {
        // Transform incoming message
        return {
            ...message,
            content: message.content.toUpperCase()
        };
    }

    protected async processOutgoing(message: Message): Promise<Message> {
        // Transform outgoing message
        return message;
    }
}
```

### 2. Content Moderator Plugin
Validates and filters message content.

```typescript
import { ContentModeratorPlugin } from '../base-plugin';

export class MyModeratorPlugin extends ContentModeratorPlugin {
    constructor() {
        super({
            id: 'my-moderator',
            name: 'My Moderator',
            version: '1.0.0',
            description: 'Moderates content',
            author: 'Your Name'
        }, {
            eventSubscriptions: ['message.created']
        });
    }

    protected async processValidation(content: string): Promise<boolean> {
        // Return true if content is valid
        return !content.includes('banned-word');
    }

    protected async processSanitization(content: string): Promise<string> {
        // Clean up content
        return content.replace(/bad-word/g, '***');
    }
}
```

### 3. Event Handler Plugin
Responds to specific events in the system.

```typescript
import { BasePlugin } from '../base-plugin';
import { RoomEvent } from '../types';

export class MyEventPlugin extends BasePlugin {
    constructor() {
        super({
            id: 'my-event-handler',
            name: 'My Event Handler',
            version: '1.0.0',
            description: 'Handles events',
            author: 'Your Name'
        }, {
            eventSubscriptions: [
                RoomEvent.MESSAGE_CREATED,
                RoomEvent.PARTICIPANT_JOINED
            ]
        });
    }

    async initialize(): Promise<void> {
        await super.initialize();
        // Set up event handlers
        this.setupEventHandlers();
    }

    private setupEventHandlers(): void {
        // Handle message created
        this.on(RoomEvent.MESSAGE_CREATED, async (data) => {
            console.log('New message:', data);
        });

        // Handle participant joined
        this.on(RoomEvent.PARTICIPANT_JOINED, async (data) => {
            console.log('Participant joined:', data);
        });
    }
}
```

## Common Plugin Patterns

### 1. State Management
```typescript
export class StatefulPlugin extends BasePlugin {
    private state: Map<string, any> = new Map();

    protected async setState(key: string, value: any): Promise<void> {
        this.state.set(key, value);
    }

    protected async getState(key: string): Promise<any> {
        return this.state.get(key);
    }

    protected async clearState(): Promise<void> {
        this.state.clear();
    }
}
```

### 2. Configuration Management
```typescript
export class ConfigurablePlugin extends BasePlugin {
    protected getConfig<T>(key: string, defaultValue: T): T {
        return this.config.customConfig?.[key] ?? defaultValue;
    }

    protected async updateConfig(updates: Record<string, any>): Promise<void> {
        this.config.customConfig = {
            ...this.config.customConfig,
            ...updates
        };
    }
}
```

### 3. Error Handling
```typescript
export class ResilientPlugin extends BasePlugin {
    protected async withErrorHandling<T>(
        operation: () => Promise<T>,
        fallback: T
    ): Promise<T> {
        try {
            return await operation();
        } catch (error) {
            await this.onError(error as Error);
            return fallback;
        }
    }
}
```

## Plugin Development Workflow

### 1. Setting Up Development Environment
```bash
# Create plugin directory
mkdir my-plugin
cd my-plugin

# Initialize package
npm init -y

# Install dependencies
npm install @echochamber/plugin-system
npm install typescript @types/node --save-dev

# Create TypeScript config
cat > tsconfig.json << EOF
{
    "compilerOptions": {
        "target": "ES2020",
        "module": "commonjs",
        "outDir": "./dist",
        "strict": true,
        "esModuleInterop": true
    },
    "include": ["src/**/*"]
}
EOF
```

### 2. Development Process
1. Create plugin class
2. Implement required methods
3. Test locally
4. Build and package
5. Deploy to EchoChamber

### 3. Testing Your Plugin
```typescript
import { MyPlugin } from './my-plugin';

describe('MyPlugin', () => {
    let plugin: MyPlugin;

    beforeEach(() => {
        plugin = new MyPlugin();
    });

    it('should handle events correctly', async () => {
        const event = {
            type: 'message.created',
            data: {
                content: 'test message',
                sender: 'user1'
            }
        };

        await plugin.handleEvent(event);
        // Add assertions
    });
});
```

## Integration Examples

### 1. OpenAI Chat Bot
```typescript
import { BasePlugin } from '@echochamber/plugin-system';
import OpenAI from 'openai';

export class OpenAIPlugin extends BasePlugin {
    private openai: OpenAI;

    constructor() {
        super({
            id: 'openai-chat-bot',
            name: 'OpenAI Chat Bot',
            version: '1.0.0',
            description: 'AI-powered chat bot',
            author: 'Your Name'
        }, {
            eventSubscriptions: ['message.created'],
            customConfig: {
                model: 'gpt-3.5-turbo',
                temperature: 0.7
            }
        });

        this.openai = new OpenAI({
            apiKey: process.env.OPENAI_API_KEY
        });
    }

    async handleMessage(message: any): Promise<void> {
        const response = await this.openai.chat.completions.create({
            model: this.config.customConfig.model,
            messages: [{ role: 'user', content: message.content }],
            temperature: this.config.customConfig.temperature
        });

        // Send response back to room
        await this.sendMessage(message.roomId, response.choices[0].message.content);
    }
}
```

### 2. Message Filter
```typescript
import { ContentModeratorPlugin } from '@echochamber/plugin-system';

export class ProfanityFilter extends ContentModeratorPlugin {
    private bannedWords: Set<string>;

    constructor() {
        super({
            id: 'profanity-filter',
            name: 'Profanity Filter',
            version: '1.0.0',
            description: 'Filters profanity from messages',
            author: 'Your Name'
        }, {
            eventSubscriptions: ['message.created']
        });

        this.bannedWords = new Set(['bad', 'words', 'here']);
    }

    protected async processValidation(content: string): Promise<boolean> {
        const words = content.toLowerCase().split(' ');
        return !words.some(word => this.bannedWords.has(word));
    }

    protected async processSanitization(content: string): Promise<string> {
        return content.split(' ')
            .map(word => this.bannedWords.has(word.toLowerCase()) ? '***' : word)
            .join(' ');
    }
}
```

## Best Practices

### 1. Plugin Design
- Keep plugins focused and single-purpose
- Use dependency injection where possible
- Implement proper cleanup in terminate()
- Handle errors gracefully
- Use TypeScript for type safety

### 2. State Management
- Use immutable state when possible
- Implement state cleanup
- Handle state persistence
- Use atomic operations

### 3. Performance
- Implement caching where appropriate
- Batch operations when possible
- Use async/await properly
- Handle timeouts
- Implement retry logic

### 4. Security
- Validate all inputs
- Sanitize outputs
- Use proper authentication
- Implement rate limiting
- Handle sensitive data properly

## Debugging Tips

### 1. Plugin Debugging
```typescript
protected async debugLog(message: string, data?: any): Promise<void> {
    if (this.config.customConfig?.debug) {
        console.log(`[${this.metadata.id}] ${message}`, data);
    }
}
```

### 2. Event Debugging
```typescript
protected async logEvent(event: string, data: any): Promise<void> {
    await this.debugLog(`Event ${event}`, {
        timestamp: new Date().toISOString(),
        data
    });
}
```

### 3. Performance Monitoring
```typescript
protected async measurePerformance<T>(
    operation: () => Promise<T>,
    label: string
): Promise<T> {
    const start = performance.now();
    const result = await operation();
    const duration = performance.now() - start;
    await this.debugLog(`${label} took ${duration}ms`);
    return result;
}
```

## Deployment Checklist

1. **Pre-deployment**
   - [ ] All tests passing
   - [ ] Documentation updated
   - [ ] Dependencies verified
   - [ ] Configuration validated
   - [ ] Performance tested

2. **Deployment**
   - [ ] Build plugin
   - [ ] Package assets
   - [ ] Update configuration
   - [ ] Deploy plugin
   - [ ] Verify registration

3. **Post-deployment**
   - [ ] Monitor logs
   - [ ] Check performance
   - [ ] Verify functionality
   - [ ] Monitor errors
   - [ ] Check resource usage
