# Contributing to EchoChamber Plugin System

## Overview

The EchoChamber Plugin System is designed to be extensible and maintainable. This guide will help you understand how to contribute effectively.

## Development Setup

1. **Fork and Clone**
```bash
git clone https://github.com/yourusername/echochambers.git
cd echochambers
```

2. **Install Dependencies**
```bash
npm install
```

3. **Environment Setup**
```bash
cp .env.example .env
# Edit .env with your configuration
```

## Development Workflow

### 1. Creating a New Plugin

```typescript
import { BasePlugin, PluginMetadata, PluginConfig } from '../types';

export class MyPlugin extends BasePlugin {
    constructor() {
        const metadata: PluginMetadata = {
            id: 'my-plugin',
            name: 'My Plugin',
            version: '1.0.0',
            description: 'Description of my plugin',
            author: 'Your Name'
        };

        const config: PluginConfig = {
            apiKey: process.env.MY_PLUGIN_API_KEY,
            eventSubscriptions: ['message.created']
        };

        super(metadata, config);
    }

    async initialize(): Promise<void> {
        // Your initialization logic
    }

    async terminate(): Promise<void> {
        // Your cleanup logic
    }
}
```

### 2. Testing Your Plugin

1. **Unit Tests**
```typescript
import { MyPlugin } from './my-plugin';

describe('MyPlugin', () => {
    let plugin: MyPlugin;

    beforeEach(() => {
        plugin = new MyPlugin();
    });

    it('should initialize correctly', async () => {
        await plugin.initialize();
        // Add assertions
    });
});
```

2. **Integration Tests**
```typescript
describe('Plugin Integration', () => {
    it('should handle events correctly', async () => {
        const event = {
            type: 'message.created',
            data: { /* ... */ }
        };
        // Test event handling
    });
});
```

## Code Style Guidelines

### 1. TypeScript Best Practices

- Use strict type checking
- Avoid `any` types
- Use interfaces for object shapes
- Document complex types

```typescript
// Good
interface MessageData {
    content: string;
    sender: string;
    timestamp: Date;
}

function processMessage(data: MessageData): void {
    // Implementation
}

// Bad
function processMessage(data: any): void {
    // Implementation
}
```

### 2. Error Handling

```typescript
// Good
try {
    await this.processEvent(event);
} catch (error) {
    if (error instanceof PluginError) {
        // Handle plugin-specific error
    } else {
        // Handle general error
    }
}

// Bad
try {
    await this.processEvent(event);
} catch (error) {
    console.error(error);
}
```

### 3. Async/Await

```typescript
// Good
async function handleEvent(): Promise<void> {
    try {
        await this.validateEvent();
        await this.processEvent();
    } catch (error) {
        await this.handleError(error);
    }
}

// Bad
function handleEvent(): Promise<void> {
    return this.validateEvent()
        .then(() => this.processEvent())
        .catch(error => this.handleError(error));
}
```

## Documentation Guidelines

### 1. Code Comments

```typescript
/**
 * Processes an incoming event from the chat system.
 * 
 * @param event - The event to process
 * @throws {PluginError} If event processing fails
 * @returns Promise that resolves when processing is complete
 */
async processEvent(event: Event): Promise<void> {
    // Implementation
}
```

### 2. README Updates

- Update relevant documentation
- Add examples for new features
- Document breaking changes
- Include upgrade guides

## Pull Request Process

1. **Branch Naming**
```bash
feature/my-new-feature
bugfix/issue-description
improvement/performance-enhancement
```

2. **Commit Messages**
```bash
# Good
feat: add new message transformation capability
fix: resolve webhook timeout issue
docs: update plugin development guide

# Bad
update code
fix bug
add feature
```

3. **PR Description Template**
```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
Describe testing performed

## Checklist
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] Code follows style guidelines
- [ ] All tests passing
```

## Release Process

1. **Version Bump**
```bash
npm version patch # For bug fixes
npm version minor # For new features
npm version major # For breaking changes
```

2. **Changelog Update**
```markdown
## [1.1.0] - 2024-01-15
### Added
- New feature X
- Support for Y

### Fixed
- Issue with Z
- Performance problem with W
```

3. **Release Notes**
- Document breaking changes
- Include upgrade instructions
- List new features
- Acknowledge contributors

## Getting Help

- Join our Discord server
- Check GitHub Issues
- Review documentation
- Contact maintainers

## Code of Conduct

See [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md) for our community guidelines.

## License

By contributing, you agree that your contributions will be licensed under the project's MIT License.
